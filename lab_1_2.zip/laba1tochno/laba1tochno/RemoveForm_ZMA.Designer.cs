﻿namespace laba1tochno
{
    partial class RemoveForm_ZMA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SaveChangesButton_ZMA = new System.Windows.Forms.Button();
            this.CancelButton_ZMA = new System.Windows.Forms.Button();
            this.Car_ZMA = new System.Windows.Forms.TextBox();
            this.СarRepair_ZMA = new System.Windows.Forms.TextBox();
            this.Owner_ZMA = new System.Windows.Forms.TextBox();
            this.Master_ZMA = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // SaveChangesButton_ZMA
            // 
            this.SaveChangesButton_ZMA.Location = new System.Drawing.Point(211, 389);
            this.SaveChangesButton_ZMA.Name = "SaveChangesButton_ZMA";
            this.SaveChangesButton_ZMA.Size = new System.Drawing.Size(100, 47);
            this.SaveChangesButton_ZMA.TabIndex = 0;
            this.SaveChangesButton_ZMA.Text = "Сохранить";
            this.SaveChangesButton_ZMA.UseVisualStyleBackColor = true;
            this.SaveChangesButton_ZMA.Click += new System.EventHandler(this.SaveChangesButton_ZMA_Click);
            // 
            // CancelButton_ZMA
            // 
            this.CancelButton_ZMA.Location = new System.Drawing.Point(12, 389);
            this.CancelButton_ZMA.Name = "CancelButton_ZMA";
            this.CancelButton_ZMA.Size = new System.Drawing.Size(100, 47);
            this.CancelButton_ZMA.TabIndex = 1;
            this.CancelButton_ZMA.Text = "Отмена";
            this.CancelButton_ZMA.UseVisualStyleBackColor = true;
            this.CancelButton_ZMA.Click += new System.EventHandler(this.CancelButton_ZMA_Click);
            // 
            // Car_ZMA
            // 
            this.Car_ZMA.Location = new System.Drawing.Point(99, 154);
            this.Car_ZMA.Name = "Car_ZMA";
            this.Car_ZMA.Size = new System.Drawing.Size(175, 22);
            this.Car_ZMA.TabIndex = 2;
            // 
            // СarRepair_ZMA
            // 
            this.СarRepair_ZMA.Location = new System.Drawing.Point(99, 100);
            this.СarRepair_ZMA.Name = "СarRepair_ZMA";
            this.СarRepair_ZMA.Size = new System.Drawing.Size(175, 22);
            this.СarRepair_ZMA.TabIndex = 3;
            // 
            // Owner_ZMA
            // 
            this.Owner_ZMA.Location = new System.Drawing.Point(99, 206);
            this.Owner_ZMA.Name = "Owner_ZMA";
            this.Owner_ZMA.Size = new System.Drawing.Size(175, 22);
            this.Owner_ZMA.TabIndex = 4;
            // 
            // Master_ZMA
            // 
            this.Master_ZMA.Location = new System.Drawing.Point(99, 262);
            this.Master_ZMA.Name = "Master_ZMA";
            this.Master_ZMA.Size = new System.Drawing.Size(175, 22);
            this.Master_ZMA.TabIndex = 5;
      
            // 
            // RemoveForm_ZMA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(323, 448);
            this.Controls.Add(this.Master_ZMA);
            this.Controls.Add(this.Owner_ZMA);
            this.Controls.Add(this.СarRepair_ZMA);
            this.Controls.Add(this.Car_ZMA);
            this.Controls.Add(this.CancelButton_ZMA);
            this.Controls.Add(this.SaveChangesButton_ZMA);
            this.MaximizeBox = false;
            this.Name = "RemoveForm_ZMA";
            this.Text = "Создание сущьности";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SaveChangesButton_ZMA;
        private System.Windows.Forms.Button CancelButton_ZMA;
        private System.Windows.Forms.TextBox Car_ZMA;
        private System.Windows.Forms.TextBox СarRepair_ZMA;
        private System.Windows.Forms.TextBox Owner_ZMA;
        private System.Windows.Forms.TextBox Master_ZMA;
    }
}