﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laba1tochno
{
    public partial class SearchDialogForm : Form
    {
        public event Action<string, string> SearchPerformed;

        public SearchDialogForm(string[] columns)
        {
            InitializeComponent();

            // Добавляем столбцы в ComboBox
            ColumnComboBox.Items.AddRange(columns);
            // Устанавливаем первый столбец как выбранный по умолчанию
            if (columns.Length > 0)
                ColumnComboBox.SelectedIndex = 0;
        }

        private void InitializeComboBox(string[] columns)
        {
            // Добавьте логику для заполнения ComboBox столбцами
            // Например:
            // foreach (var column in columns)
            // {
            //     ColumnComboBox.Items.Add(column);
            // }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            // Получите выбранный столбец и текст для поиска
            string selectedColumn = ColumnComboBox.SelectedItem.ToString();
            string searchText = SearchTextBox.Text;

            // Вызовите событие SearchPerformed и передайте выбранный столбец и текст для поиска
            SearchPerformed?.Invoke(selectedColumn, searchText);

            // Закройте форму поиска
            this.Close();
        }
    }
}
