﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace laba1tochno
{
    public partial class AddEntityForm_ZMA : Form
    {
        private List<string> autoRepairData;
        private List<string> carData;
        private List<string> carOwnerData;
        private List<string> mechanicData;
        public AddEntityForm_ZMA(List<string> autoRepairData, List<string> carData, List<string> carOwnerData, List<string> mechanicData)
        {
            InitializeComponent();

            this.autoRepairData = autoRepairData;
            this.carData = carData;
            this.carOwnerData = carOwnerData;
            this.mechanicData = mechanicData;

            FillComboBox(ComboBoxCarRepair_ZM, autoRepairData);
            FillComboBox(comboBoxCar_ZM, carData);
            FillComboBox(comboBoxOwner_ZM, carOwnerData);
            FillComboBox(comboBoxMaster_ZM, mechanicData);
        }
        private void FillComboBox(ComboBox comboBox, List<string> data)
        {
            comboBox.Items.Clear();
            comboBox.Items.AddRange(data.ToArray());
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void СonfirmButton_ZM_Click(object sender, EventArgs e)
        {
            string selectedCarRepair = ComboBoxCarRepair_ZM.SelectedItem.ToString();
            string selectedCar = comboBoxCar_ZM.SelectedItem.ToString();
            string selectedOwner = comboBoxOwner_ZM.SelectedItem.ToString();
            string selectedMaster = comboBoxMaster_ZM.SelectedItem.ToString();

            string newEntry = $"{selectedCarRepair},{selectedCar},{selectedOwner},{selectedMaster}";

            string rootFilePath = "root.txt";

            try
            {
                File.AppendAllText(rootFilePath, newEntry + Environment.NewLine);
                MessageBox.Show("Запись успешно добавлена в базу данных root!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка при добавлении записи в базу данных root: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void СloseButton_Zm_Click(object sender, EventArgs e)
        {
            // Закрываем форму
            this.Close();

            // Очищаем все ComboBox
            ComboBoxCarRepair_ZM.SelectedIndex = -1;
            comboBoxCar_ZM.SelectedIndex = -1;
            comboBoxOwner_ZM.SelectedIndex = -1;
            comboBoxMaster_ZM.SelectedIndex = -1;
        }
    }
}
