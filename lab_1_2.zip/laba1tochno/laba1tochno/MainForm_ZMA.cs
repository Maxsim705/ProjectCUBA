﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace laba1tochno
{
    public partial class MainForm_ZMA : Form
    {
        private const string CarDatabasePath = "car.txt";
        private const string MechanicDatabasePath = "mechanic.txt";

        public MainForm_ZMA()
        {
            InitializeComponent();
            InitializeComboBox_ZMA();
            SearchButton_ZMA.Click += SearchButton_ZMA_Click;

        }

        private void InitializeComboBox_ZMA()
        {
            DataBaseComboBox_ZMA.Items.Add("car");
            DataBaseComboBox_ZMA.Items.Add("mechanic");
            DataBaseComboBox_ZMA.Items.Add("AutoRepair");
            DataBaseComboBox_ZMA.Items.Add("CarOvner");
            DataBaseComboBox_ZMA.Items.Add("root");
            DataBaseComboBox_ZMA.SelectedIndex = 0;
        }


        private void LoadDataToDataGridView_ZMA(string selectedDatabase)
        {
            DataTable dataTable = new DataTable();

       
            List<string> columns = GetColumnsForTable_ZMA(selectedDatabase);

        
            foreach (string column in columns)
            {
                if (!dataTable.Columns.Contains(column))
                {
                    dataTable.Columns.Add(column);
                }
            }

            string filePath = selectedDatabase + ".txt";

            try
            {
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] values = line.Split(',');
                    dataTable.Rows.Add(values);
                }

                OutputWindow_ZMA.DataSource = dataTable;
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show($"Файл {filePath} не найден.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void LoadingButton_ZMA_Click(object sender, EventArgs e)
        {
            string selectedDatabase = DataBaseComboBox_ZMA.SelectedItem.ToString();
            LoadDataToDataGridView_ZMA(selectedDatabase);
        }

        private void AddEntity_ZMA_Click(object sender, EventArgs e)
        {
            string selectedDatabase = DataBaseComboBox_ZMA.SelectedItem.ToString();
            string filePath = selectedDatabase + ".txt";

            string[] newEntry = new string[]
            {
                TextBoxNamber_ZMA.Text,
                TextBoxName_ZMA.Text,
                TextBoxAdres_ZMA.Text,
                TextBoxColor_ZMA.Text
            };

            try
            {
                File.AppendAllText(filePath, string.Join(",", newEntry) + Environment.NewLine);
                MessageBox.Show("Запись успешно добавлена!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void Delete_ZMA_Click(object sender, EventArgs e)
        {
            string selectedDatabase = DataBaseComboBox_ZMA.SelectedItem.ToString();
            string filePath = selectedDatabase + ".txt";

            int selectedRowIndex = OutputWindow_ZMA.CurrentCell.RowIndex;
            DataTable dataTable = (DataTable)OutputWindow_ZMA.DataSource;

            if (selectedRowIndex >= 0 && selectedRowIndex < dataTable.Rows.Count)
            {
                dataTable.Rows[selectedRowIndex].Delete();
                dataTable.AcceptChanges();

                List<string> lines = new List<string>();

                foreach (DataRow row in dataTable.Rows)
                {
                    lines.Add(string.Join(",", row.ItemArray));
                }

                try
                {
                    File.WriteAllLines(filePath, lines);
                    MessageBox.Show("Запись успешно удалена!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку для удаления.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DataBaseComboBox_ZMA_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedDatabase = DataBaseComboBox_ZMA.SelectedItem.ToString();

            // Получите столбцы для выбранной таблицы
            List<string> columns = GetColumnsForTable_ZMA(selectedDatabase);

            // Удалите все столбцы в DataGridView
            OutputWindow_ZMA.Columns.Clear();

            LoadDataToDataGridView_ZMA(selectedDatabase);
        }

        private void AddRootButton_ZMA_Click(object sender, EventArgs e)
        {
            AddEntityForm_ZMA formAddRootEntity = new AddEntityForm_ZMA(
                LoadDataFromDatabase_ZMA("AutoRepair", 1), // Например, 1 для столбца с названием
                LoadDataFromDatabase_ZMA("car", 0),         // Например, 0 для столбца с номером машины
                LoadDataFromDatabase_ZMA("CarOvner", 1),    // Например, 1 для столбца с ФИО
                LoadDataFromDatabase_ZMA("mechanic", 1)     // Например, 1 для столбца с ФИО сотрудника
            );

            formAddRootEntity.ShowDialog();

            // После закрытия FormAddRootEntity, можно обновить данные на главной форме, если это необходимо.
            LoadDataToDataGridView_ZMA(DataBaseComboBox_ZMA.SelectedItem.ToString());
        }

        private List<string> LoadDataFromDatabase_ZMA(string selectedDatabase, int columnIndex)
        {
            List<string> data = new List<string>();
            string filePath = selectedDatabase + ".txt";

            try
            {
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    string[] values = line.Split(',');
                    if (columnIndex >= 0 && columnIndex < values.Length)
                    {
                        data.Add(values[columnIndex]);
                    }
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show($"Файл {filePath} не найден.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return data;
        }

        private void Change_ZMA_Click(object sender, EventArgs e)
        {
            // Получите выбранные данные из DataGridView
            DataGridViewRow selectedRow = OutputWindow_ZMA.CurrentRow;
            if (selectedRow == null)
            {
                MessageBox.Show("Выберите строку для редактирования.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

          
            string selectedCarRepair = selectedRow.Cells["номер"].Value?.ToString();
            string selectedCar = selectedRow.Cells["машина"].Value?.ToString();
            string selectedOwner = selectedRow.Cells["владелец"].Value?.ToString();
            string selectedMaster = selectedRow.Cells["механик"].Value?.ToString();

            RemoveForm_ZMA editForm = new RemoveForm_ZMA(selectedCarRepair, selectedCar, selectedOwner, selectedMaster);
            DialogResult result = editForm.ShowDialog();

            // Если пользователь нажал "ОК" после редактирования, обновите данные в DataGridView
            if (result == DialogResult.OK)
            {
             
                LoadDataToDataGridView_ZMA(DataBaseComboBox_ZMA.SelectedItem.ToString());
            }
        }


        private string GetCellValue_ZMA(DataGridViewRow row, string database, string columnName)
        {
            // Проверка наличия выбранной базы данных в словаре
            if (columnMappings.ContainsKey(database))
            {
                // Получите соответствующие имена столбцов для выбранной базы данных
                List<string> columns = columnMappings[database];

                // Проверка наличия выбранного столбца в списке имен столбцов
                if (columns.Contains(columnName))
                {
                    // Имя столбца совпадает, возвращаем значение ячейки
                    return row.Cells[columnName].Value?.ToString();
                }
            }

            // Если что-то пошло не так, возвращаем пустую строку или можете обработать ошибку по вашему усмотрению
            return string.Empty;
        }

        private Dictionary<string, List<string>> columnMappings = new Dictionary<string, List<string>>
        {
            { "car", new List<string> { "Номер машины", "Марка машины", "Мощность", "Цвет" } },
            { "mechanic", new List<string> { "Номер сотрудника", "ФИО сотрудника", "Адрес", "Телефон", "Квалификация" } },
            { "AutoRepair", new List<string> { "номер", "название", "адрес", "телефон" } },
            { "CarOvner", new List<string> { "номер водительских прав", "фио", "адрес", "телефон" } },
            { "root", new List<string> { "автомастерская", "машина", "владелец", "механик" } }
        };

        // Метод для получения столбцов по выбранной таблице
        private List<string> GetColumnsForTable_ZMA(string selectedDatabase)
        {
            if (columnMappings.ContainsKey(selectedDatabase))
            {
                return columnMappings[selectedDatabase];
            }
            return new List<string>();
        }

        private void ShowStatistics_ZMA(string selectedDatabase)
        {
            DataTable dataTable = (DataTable)OutputWindow_ZMA.DataSource;

            if (dataTable != null)
            {
                int rowCount = dataTable.Rows.Count;

                // Подсчет количества машин каждого цвета
                Dictionary<string, int> carColorCounts = new Dictionary<string, int>();
                foreach (DataRow row in dataTable.Rows)
                {
                    string carColor = row["Цвет"].ToString();
                    if (carColorCounts.ContainsKey(carColor))
                    {
                        carColorCounts[carColor]++;
                    }
                    else
                    {
                        carColorCounts.Add(carColor, 1);
                    }
                }

                // Формирование строки статистики
                string statistics = $"Статистика для базы данных '{selectedDatabase}':\nКоличество записей: {rowCount}\n\n";
                statistics += "Количество машин по цветам:\n";
                foreach (var kvp in carColorCounts)
                {
                    statistics += $"{kvp.Key}: {kvp.Value}\n";
                }

                MessageBox.Show(statistics, "Статистика", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Данные не загружены. Выберите базу данных и загрузите данные перед просмотром статистики.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void StatistickButton_ZMA_Click(object sender, EventArgs e)
        {
            string selectedDatabase = DataBaseComboBox_ZMA.SelectedItem.ToString();

            // Обработка статистики в зависимости от выбранной базы данных
            ShowStatistics_ZMA(selectedDatabase);
        }

        private void SearchButton_ZMA_Click(object sender, EventArgs e)
        {
            // Получаем выбранную базу данных
            string selectedDatabase = DataBaseComboBox_ZMA.SelectedItem.ToString();

            // Получаем столбцы для выбранной таблицы
            List<string> columns = GetColumnsForTable_ZMA(selectedDatabase);

            // Создаем форму для поиска и передаем ей список столбцов
            SearchDialogForm searchForm = new SearchDialogForm(columns.ToArray());

            // Подписываемся на событие поиска
            searchForm.SearchPerformed += SearchForm_SearchPerformed_ZMA;

            // Отображаем форму для поиска
            searchForm.ShowDialog();
        }

        private void SearchForm_SearchPerformed_ZMA(string selectedColumn, string searchText)
        {
            // Фильтруем данные в DataGridView
            FilterData_ZMA(selectedColumn, searchText);
        }

        private void FilterData_ZMA(string searchColumn, string searchText)
        {
            DataTable dataTable = (DataTable)OutputWindow_ZMA.DataSource;

            if (dataTable != null)
            {
                // Устанавливаем фильтр для строки данных в DataTable
                dataTable.DefaultView.RowFilter = $"{searchColumn} LIKE '%{searchText}%'";
            }
            else
            {
                MessageBox.Show("Данные не загружены. Выберите базу данных и загрузите данные перед выполнением поиска.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void OnSearch_ZMA_Click(object sender, EventArgs e)
        {
            ResetSearchFilters_ZMA();
        }
        private void ResetSearchFilters_ZMA()
        {
            // Очищаем строку фильтрации в DataGridView
            DataTable dataTable = (DataTable)OutputWindow_ZMA.DataSource;
            if (dataTable != null)
            {
                dataTable.DefaultView.RowFilter = string.Empty;
            }
        }

        private void schedule_batton_ZMA_Click(object sender, EventArgs e)
        {
            // Создаем форму с графиком
            Graphick_ZMA graphForm = new Graphick_ZMA();

            Dictionary<string, int> carData = GenerateChartDataFromCarDatabase_ZMA();

            graphForm.FillChartWithData_ZMA(carData);
       
            graphForm.Show();
        }
        private List<string> LoadDataFromData_ZMA(string selectedDatabase)
        {
            List<string> data = new List<string>();
            string filePath = selectedDatabase + ".txt";

            try
            {
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    data.Add(line); 
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show($"Файл {filePath} не найден.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return data;
        }



        private Dictionary<string, int> GenerateChartDataFromCarDatabase_ZMA()
        {
            Dictionary<string, int> data = new Dictionary<string, int>();

            // Получаем все строки данных из базы данных "car"
            List<string> carData = LoadDataFromData_ZMA("car");

            // Проходим по каждой строке данных и добавляем их в словарь
            foreach (string line in carData)
            {
                string[] values = line.Split(',');
                if (values.Length >= 4) // Проверяем, содержит ли строка минимум четыре значения (все столбцы)
                {
                    string carBrand = values[1]; // Получаем марку машины (индекс 1)
                    if (int.TryParse(values[2], out int power)) // Пытаемся преобразовать третье значение (мощность) в целое число
                    {
                        data.Add(carBrand, power); // Добавляем данные в словарь
                    }
                    else
                    {
                        // Если не удалось преобразовать мощность в целое число, выводим сообщение об ошибке или обрабатываем ее по вашему усмотрению
                        MessageBox.Show($"Ошибка преобразования мощности машины: {values[2]}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    // Если строка содержит менее четырех значений, это может быть ошибка в данных. Обработайте ее соответственно.
                    MessageBox.Show($"Неправильный формат строки данных: {line}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            return data;
        }


    }
}


   