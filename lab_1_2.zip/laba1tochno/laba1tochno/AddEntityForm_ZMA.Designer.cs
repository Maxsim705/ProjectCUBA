﻿namespace laba1tochno
{
    partial class AddEntityForm_ZMA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ComboBoxCarRepair_ZM = new System.Windows.Forms.ComboBox();
            this.comboBoxCar_ZM = new System.Windows.Forms.ComboBox();
            this.comboBoxOwner_ZM = new System.Windows.Forms.ComboBox();
            this.comboBoxMaster_ZM = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.СonfirmButton_ZM = new System.Windows.Forms.Button();
            this.СloseButton_Zm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ComboBoxCarRepair_ZM
            // 
            this.ComboBoxCarRepair_ZM.FormattingEnabled = true;
            this.ComboBoxCarRepair_ZM.Location = new System.Drawing.Point(39, 98);
            this.ComboBoxCarRepair_ZM.Name = "ComboBoxCarRepair_ZM";
            this.ComboBoxCarRepair_ZM.Size = new System.Drawing.Size(187, 24);
            this.ComboBoxCarRepair_ZM.TabIndex = 0;
            // 
            // comboBoxCar_ZM
            // 
            this.comboBoxCar_ZM.FormattingEnabled = true;
            this.comboBoxCar_ZM.Location = new System.Drawing.Point(39, 175);
            this.comboBoxCar_ZM.Name = "comboBoxCar_ZM";
            this.comboBoxCar_ZM.Size = new System.Drawing.Size(187, 24);
            this.comboBoxCar_ZM.TabIndex = 1;
            // 
            // comboBoxOwner_ZM
            // 
            this.comboBoxOwner_ZM.FormattingEnabled = true;
            this.comboBoxOwner_ZM.Location = new System.Drawing.Point(39, 257);
            this.comboBoxOwner_ZM.Name = "comboBoxOwner_ZM";
            this.comboBoxOwner_ZM.Size = new System.Drawing.Size(187, 24);
            this.comboBoxOwner_ZM.TabIndex = 2;
            // 
            // comboBoxMaster_ZM
            // 
            this.comboBoxMaster_ZM.FormattingEnabled = true;
            this.comboBoxMaster_ZM.Location = new System.Drawing.Point(39, 344);
            this.comboBoxMaster_ZM.Name = "comboBoxMaster_ZM";
            this.comboBoxMaster_ZM.Size = new System.Drawing.Size(187, 24);
            this.comboBoxMaster_ZM.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(187, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "выберите автомастерскую ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "выберите машину";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(39, 238);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(199, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "выберите владельца машины";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 325);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "выберите механика";
            // 
            // СonfirmButton_ZM
            // 
            this.СonfirmButton_ZM.Location = new System.Drawing.Point(309, 115);
            this.СonfirmButton_ZM.Name = "СonfirmButton_ZM";
            this.СonfirmButton_ZM.Size = new System.Drawing.Size(169, 187);
            this.СonfirmButton_ZM.TabIndex = 8;
            this.СonfirmButton_ZM.Text = "Добавить";
            this.СonfirmButton_ZM.UseVisualStyleBackColor = true;
            this.СonfirmButton_ZM.Click += new System.EventHandler(this.СonfirmButton_ZM_Click);
            // 
            // СloseButton_Zm
            // 
            this.СloseButton_Zm.Location = new System.Drawing.Point(595, 115);
            this.СloseButton_Zm.Name = "СloseButton_Zm";
            this.СloseButton_Zm.Size = new System.Drawing.Size(169, 187);
            this.СloseButton_Zm.TabIndex = 9;
            this.СloseButton_Zm.Text = "Отменить";
            this.СloseButton_Zm.UseVisualStyleBackColor = true;
            this.СloseButton_Zm.Click += new System.EventHandler(this.СloseButton_Zm_Click);
            // 
            // AddEntityForm_ZMA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.СloseButton_Zm);
            this.Controls.Add(this.СonfirmButton_ZM);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxMaster_ZM);
            this.Controls.Add(this.comboBoxOwner_ZM);
            this.Controls.Add(this.comboBoxCar_ZM);
            this.Controls.Add(this.ComboBoxCarRepair_ZM);
            this.MaximizeBox = false;
            this.Name = "AddEntityForm_ZMA";
            this.Text = "Форма добавления ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox ComboBoxCarRepair_ZM;
        private System.Windows.Forms.ComboBox comboBoxCar_ZM;
        private System.Windows.Forms.ComboBox comboBoxOwner_ZM;
        private System.Windows.Forms.ComboBox comboBoxMaster_ZM;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button СonfirmButton_ZM;
        private System.Windows.Forms.Button СloseButton_Zm;
    }
}