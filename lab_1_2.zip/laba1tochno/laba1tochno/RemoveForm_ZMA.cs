﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laba1tochno
{
    public partial class RemoveForm_ZMA : Form
    {
        public string EditedCarRepair { get; private set; }
        public string EditedCar { get; private set; }
        public string EditedOwner { get; private set; }
        public string EditedMaster { get; private set; }

        public RemoveForm_ZMA(string carRepair, string car, string owner, string master)
        {
            InitializeComponent();

            // Заполните элементы управления значениями выбранных данных
            СarRepair_ZMA.Text = carRepair;
            Car_ZMA.Text = car;
            Owner_ZMA.Text = owner;
            Master_ZMA.Text = master;

            EditedCarRepair = carRepair;
            EditedCar = car;
            EditedOwner = owner;
            EditedMaster = master;
        }


        private void CancelButton_ZMA_Click(object sender, EventArgs e)
        {
            // Закройте форму без сохранения изменений
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void SaveChangesButton_ZMA_Click(object sender, EventArgs e)
        {
            // Получите значения из элементов управления и сохраните в соответствующих свойствах
            EditedCarRepair = СarRepair_ZMA.Text;
            EditedCar = Car_ZMA.Text;
            EditedOwner = Owner_ZMA.Text;
            EditedMaster = Master_ZMA.Text;

            // Закройте форму
            DialogResult = DialogResult.OK;
            Close();
        }

    }
}
