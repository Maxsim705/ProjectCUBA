﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace laba1tochno
{
    public partial class Graphick_ZMA : Form
    {
        private void chart1_Click(object sender, EventArgs e)
        {

        }


        // Добавьте ваш код конструктора здесь, если это необходимо
    }
}
