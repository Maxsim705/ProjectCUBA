﻿namespace laba1tochno
{
    partial class MainForm_ZMA
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.OutputWindow_ZMA = new System.Windows.Forms.DataGridView();
            this.OpenButton_ZMA = new System.Windows.Forms.Button();
            this.DataBaseComboBox_ZMA = new System.Windows.Forms.ComboBox();
            this.LoadingButton_ZMA = new System.Windows.Forms.Button();
            this.AddEntity_ZMA = new System.Windows.Forms.Button();
            this.Number_ZMA = new System.Windows.Forms.Label();
            this.NameEntity_ZMA = new System.Windows.Forms.Label();
            this.Adres_ZM = new System.Windows.Forms.Label();
            this.Power_ZMA = new System.Windows.Forms.Label();
            this.Telephone_ZMA = new System.Windows.Forms.Label();
            this.Qualification_ZM = new System.Windows.Forms.Label();
            this.Color_ZM = new System.Windows.Forms.Label();
            this.TextBoxNamber_ZMA = new System.Windows.Forms.TextBox();
            this.TextBoxName_ZMA = new System.Windows.Forms.TextBox();
            this.TextBoxAdres_ZMA = new System.Windows.Forms.TextBox();
            this.TextBoxColor_ZMA = new System.Windows.Forms.TextBox();
            this.Delete_ZMA = new System.Windows.Forms.Button();
            this.AddRootButton_ZMA = new System.Windows.Forms.Button();
            this.Change_ZMA = new System.Windows.Forms.Button();
            this.StatistickButton_ZMA = new System.Windows.Forms.Button();
            this.SearchButton_ZMA = new System.Windows.Forms.Button();
            this.OnSearch_ZMA = new System.Windows.Forms.Button();
            this.ScheduleBUtton_ZMA = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.OutputWindow_ZMA)).BeginInit();
            this.SuspendLayout();
            // 
            // OutputWindow_ZMA
            // 
            this.OutputWindow_ZMA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.OutputWindow_ZMA.Location = new System.Drawing.Point(12, 12);
            this.OutputWindow_ZMA.Name = "OutputWindow_ZMA";
            this.OutputWindow_ZMA.RowHeadersWidth = 51;
            this.OutputWindow_ZMA.RowTemplate.Height = 24;
            this.OutputWindow_ZMA.Size = new System.Drawing.Size(616, 298);
            this.OutputWindow_ZMA.TabIndex = 0;
            // 
            // OpenButton_ZMA
            // 
            this.OpenButton_ZMA.Location = new System.Drawing.Point(150, 356);
            this.OpenButton_ZMA.Name = "OpenButton_ZMA";
            this.OpenButton_ZMA.Size = new System.Drawing.Size(121, 47);
            this.OpenButton_ZMA.TabIndex = 1;
            this.OpenButton_ZMA.Text = "Открыть базу ";
            this.OpenButton_ZMA.UseVisualStyleBackColor = true;
            // 
            // DataBaseComboBox_ZMA
            // 
            this.DataBaseComboBox_ZMA.FormattingEnabled = true;
            this.DataBaseComboBox_ZMA.Location = new System.Drawing.Point(12, 316);
            this.DataBaseComboBox_ZMA.Name = "DataBaseComboBox_ZMA";
            this.DataBaseComboBox_ZMA.Size = new System.Drawing.Size(259, 24);
            this.DataBaseComboBox_ZMA.TabIndex = 2;
            this.DataBaseComboBox_ZMA.SelectedIndexChanged += new System.EventHandler(this.DataBaseComboBox_ZMA_SelectedIndexChanged);
            // 
            // LoadingButton_ZMA
            // 
            this.LoadingButton_ZMA.Location = new System.Drawing.Point(12, 356);
            this.LoadingButton_ZMA.Name = "LoadingButton_ZMA";
            this.LoadingButton_ZMA.Size = new System.Drawing.Size(121, 47);
            this.LoadingButton_ZMA.TabIndex = 3;
            this.LoadingButton_ZMA.Text = "Загрузить базу ";
            this.LoadingButton_ZMA.UseVisualStyleBackColor = true;
            this.LoadingButton_ZMA.Click += new System.EventHandler(this.LoadingButton_ZMA_Click);
            // 
            // AddEntity_ZMA
            // 
            this.AddEntity_ZMA.Location = new System.Drawing.Point(859, 143);
            this.AddEntity_ZMA.Name = "AddEntity_ZMA";
            this.AddEntity_ZMA.Size = new System.Drawing.Size(97, 47);
            this.AddEntity_ZMA.TabIndex = 4;
            this.AddEntity_ZMA.Text = "Добавить";
            this.AddEntity_ZMA.UseVisualStyleBackColor = true;
            this.AddEntity_ZMA.Click += new System.EventHandler(this.AddEntity_ZMA_Click);
            // 
            // Number_ZMA
            // 
            this.Number_ZMA.AutoSize = true;
            this.Number_ZMA.Location = new System.Drawing.Point(645, 32);
            this.Number_ZMA.Name = "Number_ZMA";
            this.Number_ZMA.Size = new System.Drawing.Size(50, 16);
            this.Number_ZMA.TabIndex = 6;
            this.Number_ZMA.Text = "Номер";
            // 
            // NameEntity_ZMA
            // 
            this.NameEntity_ZMA.AutoSize = true;
            this.NameEntity_ZMA.Location = new System.Drawing.Point(645, 60);
            this.NameEntity_ZMA.Name = "NameEntity_ZMA";
            this.NameEntity_ZMA.Size = new System.Drawing.Size(106, 16);
            this.NameEntity_ZMA.TabIndex = 7;
            this.NameEntity_ZMA.Text = "Наименование";
            // 
            // Adres_ZM
            // 
            this.Adres_ZM.AutoSize = true;
            this.Adres_ZM.Location = new System.Drawing.Point(645, 88);
            this.Adres_ZM.Name = "Adres_ZM";
            this.Adres_ZM.Size = new System.Drawing.Size(47, 16);
            this.Adres_ZM.TabIndex = 8;
            this.Adres_ZM.Text = "Адрес";
            // 
            // Power_ZMA
            // 
            this.Power_ZMA.AutoSize = true;
            this.Power_ZMA.Location = new System.Drawing.Point(645, 88);
            this.Power_ZMA.Name = "Power_ZMA";
            this.Power_ZMA.Size = new System.Drawing.Size(72, 16);
            this.Power_ZMA.TabIndex = 9;
            this.Power_ZMA.Text = "Мощность";
            // 
            // Telephone_ZMA
            // 
            this.Telephone_ZMA.AutoSize = true;
            this.Telephone_ZMA.Location = new System.Drawing.Point(645, 121);
            this.Telephone_ZMA.Name = "Telephone_ZMA";
            this.Telephone_ZMA.Size = new System.Drawing.Size(67, 16);
            this.Telephone_ZMA.TabIndex = 10;
            this.Telephone_ZMA.Text = "Телефон";
            // 
            // Qualification_ZM
            // 
            this.Qualification_ZM.AutoSize = true;
            this.Qualification_ZM.Location = new System.Drawing.Point(647, 158);
            this.Qualification_ZM.Name = "Qualification_ZM";
            this.Qualification_ZM.Size = new System.Drawing.Size(104, 16);
            this.Qualification_ZM.TabIndex = 11;
            this.Qualification_ZM.Text = "Квалификация";
            // 
            // Color_ZM
            // 
            this.Color_ZM.AutoSize = true;
            this.Color_ZM.Location = new System.Drawing.Point(669, 158);
            this.Color_ZM.Name = "Color_ZM";
            this.Color_ZM.Size = new System.Drawing.Size(39, 16);
            this.Color_ZM.TabIndex = 12;
            this.Color_ZM.Text = "Цвет";
            // 
            // TextBoxNamber_ZMA
            // 
            this.TextBoxNamber_ZMA.Location = new System.Drawing.Point(794, 26);
            this.TextBoxNamber_ZMA.Name = "TextBoxNamber_ZMA";
            this.TextBoxNamber_ZMA.Size = new System.Drawing.Size(162, 22);
            this.TextBoxNamber_ZMA.TabIndex = 13;
            // 
            // TextBoxName_ZMA
            // 
            this.TextBoxName_ZMA.Location = new System.Drawing.Point(794, 54);
            this.TextBoxName_ZMA.Name = "TextBoxName_ZMA";
            this.TextBoxName_ZMA.Size = new System.Drawing.Size(162, 22);
            this.TextBoxName_ZMA.TabIndex = 14;
            // 
            // TextBoxAdres_ZMA
            // 
            this.TextBoxAdres_ZMA.Location = new System.Drawing.Point(794, 82);
            this.TextBoxAdres_ZMA.Name = "TextBoxAdres_ZMA";
            this.TextBoxAdres_ZMA.Size = new System.Drawing.Size(162, 22);
            this.TextBoxAdres_ZMA.TabIndex = 15;
            // 
            // TextBoxColor_ZMA
            // 
            this.TextBoxColor_ZMA.Location = new System.Drawing.Point(794, 115);
            this.TextBoxColor_ZMA.Name = "TextBoxColor_ZMA";
            this.TextBoxColor_ZMA.Size = new System.Drawing.Size(162, 22);
            this.TextBoxColor_ZMA.TabIndex = 16;
            // 
            // Delete_ZMA
            // 
            this.Delete_ZMA.Location = new System.Drawing.Point(648, 143);
            this.Delete_ZMA.Name = "Delete_ZMA";
            this.Delete_ZMA.Size = new System.Drawing.Size(103, 47);
            this.Delete_ZMA.TabIndex = 17;
            this.Delete_ZMA.Text = "Удалить";
            this.Delete_ZMA.UseVisualStyleBackColor = true;
            this.Delete_ZMA.Click += new System.EventHandler(this.Delete_ZMA_Click);
            // 
            // AddRootButton_ZMA
            // 
            this.AddRootButton_ZMA.Location = new System.Drawing.Point(672, 367);
            this.AddRootButton_ZMA.Name = "AddRootButton_ZMA";
            this.AddRootButton_ZMA.Size = new System.Drawing.Size(294, 71);
            this.AddRootButton_ZMA.TabIndex = 18;
            this.AddRootButton_ZMA.Text = "Добавить в основную таблицу";
            this.AddRootButton_ZMA.UseVisualStyleBackColor = true;
            this.AddRootButton_ZMA.Click += new System.EventHandler(this.AddRootButton_ZMA_Click);
            // 
            // Change_ZMA
            // 
            this.Change_ZMA.Location = new System.Drawing.Point(757, 143);
            this.Change_ZMA.Name = "Change_ZMA";
            this.Change_ZMA.Size = new System.Drawing.Size(96, 47);
            this.Change_ZMA.TabIndex = 19;
            this.Change_ZMA.Text = "Изменить";
            this.Change_ZMA.UseVisualStyleBackColor = true;
            this.Change_ZMA.Click += new System.EventHandler(this.Change_ZMA_Click);
            // 
            // StatistickButton_ZMA
            // 
            this.StatistickButton_ZMA.Location = new System.Drawing.Point(515, 367);
            this.StatistickButton_ZMA.Name = "StatistickButton_ZMA";
            this.StatistickButton_ZMA.Size = new System.Drawing.Size(113, 71);
            this.StatistickButton_ZMA.TabIndex = 21;
            this.StatistickButton_ZMA.Text = "Статистика";
            this.StatistickButton_ZMA.UseVisualStyleBackColor = true;
            this.StatistickButton_ZMA.Click += new System.EventHandler(this.StatistickButton_ZMA_Click);
            // 
            // SearchButton_ZMA
            // 
            this.SearchButton_ZMA.Location = new System.Drawing.Point(859, 311);
            this.SearchButton_ZMA.Name = "SearchButton_ZMA";
            this.SearchButton_ZMA.Size = new System.Drawing.Size(97, 29);
            this.SearchButton_ZMA.TabIndex = 22;
            this.SearchButton_ZMA.Text = "Поиск";
            this.SearchButton_ZMA.UseVisualStyleBackColor = true;
            this.SearchButton_ZMA.Click += new System.EventHandler(this.SearchButton_ZMA_Click);
            // 
            // OnSearch_ZMA
            // 
            this.OnSearch_ZMA.Location = new System.Drawing.Point(723, 313);
            this.OnSearch_ZMA.Name = "OnSearch_ZMA";
            this.OnSearch_ZMA.Size = new System.Drawing.Size(130, 27);
            this.OnSearch_ZMA.TabIndex = 24;
            this.OnSearch_ZMA.Text = "Отменить поиск";
            this.OnSearch_ZMA.UseVisualStyleBackColor = true;
            this.OnSearch_ZMA.Click += new System.EventHandler(this.OnSearch_ZMA_Click);
            // 
            // ScheduleBUtton_ZMA
            // 
            this.ScheduleBUtton_ZMA.Location = new System.Drawing.Point(379, 367);
            this.ScheduleBUtton_ZMA.Name = "ScheduleBUtton_ZMA";
            this.ScheduleBUtton_ZMA.Size = new System.Drawing.Size(114, 71);
            this.ScheduleBUtton_ZMA.TabIndex = 25;
            this.ScheduleBUtton_ZMA.Text = "График";
            this.ScheduleBUtton_ZMA.UseVisualStyleBackColor = true;
            this.ScheduleBUtton_ZMA.Click += new System.EventHandler(this.schedule_batton_ZMA_Click);
            // 
            // MainForm_ZMA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(981, 450);
            this.Controls.Add(this.ScheduleBUtton_ZMA);
            this.Controls.Add(this.OnSearch_ZMA);
            this.Controls.Add(this.SearchButton_ZMA);
            this.Controls.Add(this.StatistickButton_ZMA);
            this.Controls.Add(this.Change_ZMA);
            this.Controls.Add(this.AddRootButton_ZMA);
            this.Controls.Add(this.Delete_ZMA);
            this.Controls.Add(this.TextBoxColor_ZMA);
            this.Controls.Add(this.TextBoxAdres_ZMA);
            this.Controls.Add(this.TextBoxName_ZMA);
            this.Controls.Add(this.TextBoxNamber_ZMA);
            this.Controls.Add(this.Color_ZM);
            this.Controls.Add(this.Qualification_ZM);
            this.Controls.Add(this.Telephone_ZMA);
            this.Controls.Add(this.Power_ZMA);
            this.Controls.Add(this.Adres_ZM);
            this.Controls.Add(this.NameEntity_ZMA);
            this.Controls.Add(this.Number_ZMA);
            this.Controls.Add(this.AddEntity_ZMA);
            this.Controls.Add(this.LoadingButton_ZMA);
            this.Controls.Add(this.DataBaseComboBox_ZMA);
            this.Controls.Add(this.OpenButton_ZMA);
            this.Controls.Add(this.OutputWindow_ZMA);
            this.MaximizeBox = false;
            this.Name = "MainForm_ZMA";
            this.Text = "Автосервис";
            ((System.ComponentModel.ISupportInitialize)(this.OutputWindow_ZMA)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView OutputWindow_ZMA;
        private System.Windows.Forms.Button OpenButton_ZMA;
        private System.Windows.Forms.ComboBox DataBaseComboBox_ZMA;
        private System.Windows.Forms.Button LoadingButton_ZMA;
        private System.Windows.Forms.Button AddEntity_ZMA;
        private System.Windows.Forms.Label Number_ZMA;
        private System.Windows.Forms.Label NameEntity_ZMA;
        private System.Windows.Forms.Label Adres_ZM;
        private System.Windows.Forms.Label Power_ZMA;
        private System.Windows.Forms.Label Telephone_ZMA;
        private System.Windows.Forms.Label Qualification_ZM;
        private System.Windows.Forms.Label Color_ZM;
        private System.Windows.Forms.TextBox TextBoxNamber_ZMA;
        private System.Windows.Forms.TextBox TextBoxName_ZMA;
        private System.Windows.Forms.TextBox TextBoxAdres_ZMA;
        private System.Windows.Forms.TextBox TextBoxColor_ZMA;
        private System.Windows.Forms.Button Delete_ZMA;
        private System.Windows.Forms.Button AddRootButton_ZMA;
        private System.Windows.Forms.Button Change_ZMA;
        private System.Windows.Forms.Button StatistickButton_ZMA;
        private System.Windows.Forms.Button SearchButton_ZMA;
        private System.Windows.Forms.Button OnSearch_ZMA;
        private System.Windows.Forms.Button ScheduleBUtton_ZMA;
    }
}

